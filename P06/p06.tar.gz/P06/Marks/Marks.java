import java.io.*;
import java.util.*;
public class Marks
{
        public static void main (String [] args)
        {
                String[] names = new String [20];
                double[] marks = new double [20];
                boolean found = false;
                int choice;

                readFile(names,marks);
                Scanner sc = new Scanner(System.in);
                do{

                        System.out.println("Select an option:\n 1.Display marks\n 2.Exit");
                        choice = sc.nextInt();

                        if (choice ==1){
                                found = output(names,marks);
                        }
                        else{
                                System.exit(0);
                        }

                }while (found == false);
        }

        public static void readFile(String[] names, double[] marks){
                Scanner sc = new Scanner(System.in);
                boolean noFile = true;
                do{
                        System.out.println("Input file name");
                        String fileName = sc.nextLine();
                        int namecount =0, markcount = 0;

                        FileInputStream fileStrm = null;
                        InputStreamReader rdr;
                        BufferedReader bufrdr;

                        try{
                                fileStrm = new FileInputStream(fileName);
                                rdr = new InputStreamReader(fileStrm);
                                bufrdr = new BufferedReader(rdr);

                                String line;
                                int lineNum = 0;

                                line = bufrdr.readLine();
                                while (line != null){
                                        if (lineNum % 2 ==0){
                                                names[namecount] = line;
                                                namecount++;
                                        }
                                        else{
                                                marks[markcount] = Double.parseDouble(line);
                                                if (marks[markcount] < 0.0){
                                                	System.out.println("Error. negative value present in file");
                                                	System.exit(0);
                                                }
                                                markcount++;
                                        }
                                        line = bufrdr.readLine();
                                        lineNum++;
                                }
                                fileStrm.close();
                                noFile = false;
                        }
                        catch (FileNotFoundException e){
                                System.out.println("File not found " + e.getMessage());
                        }
                        catch (IOException ex2){
                                System.out.println("Error in file processing");
                        }
                        catch (Exception e){
                        	throw e;
                        }
                }while (noFile == true);

        }

        public static boolean output(String[] names, double[] marks){
                Scanner sc = new Scanner(System.in);
                String name;
                boolean found = false;

                System.out.println("Input student's name");
                name = sc.nextLine();
                double mark;

                for (int i = 0; i <names.length; i++){
                        if (name.equals(names[i])){
                                mark = marks[i];
                                System.out.println("Student name is " + name + " and mark is " + mark);
                                found = true;
                        }
                }
		         if (found ==false)
		            {
		                    System.out.println(name + " does not exist");
		                    
		            }
		        
		            return found;
		 }
}
