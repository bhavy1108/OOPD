import java.util.*;
import java.io.*;
public class ShapeCalculator
{
        public static final double PI =3.14;
        public static double msq;
        public static double cmsq;
        public static double mmsq;
        
        public static double[] circle = new double [20];
        public static double[] rectangle = new double [20];
        public static double[] triangle = new double [20];

        public static void main (String [] args)
        {

                int diameter,choice;
                double length, width, base , height;
                Scanner sc = new Scanner(System.in);
                do
                {
                        System.out.println("1. Calculate area for circle\n2. Calculate area for rectangle\n3. Calculate area for triangle\n4. Calculate areas from file\n5. Exit");
                        choice = sc.nextInt();

                        while (choice <1 || choice >5)
                        {
                                System.out.println("Error. Input again");
                                choice = sc.nextInt();
                        }

                        switch(choice)
                        {
                                case 1:


                                        System.out.println("Enter the diameter (in cm) of the circle as integer.");
                                        diameter = sc.nextInt();


                                        while (diameter<=0){
                                                System.out.println("Error. Input again");
                                                diameter = sc.nextInt();}

                                        convertArea(circleCalc(diameter));

                                        System.out.println("The area of circle is :" + msq + " msq, " + cmsq + " cmsq, " + Math.floor(mmsq *100)/100 + " mmsq.");
                                        break;
                                case 2:	
                                        System.out.println("Enter the length (in cm) of the rectangle as real.");
                                        length = sc.nextDouble();


                                        while (length<=0){
                                                System.out.println("Error. Input again");
                                                length = sc.nextDouble();}
                                        System.out.println("Enter the width (in cm) of the rectangle as real.");
                                        width = sc.nextDouble();


                                        while (width<=0){
                                                System.out.println("Error. Input again");
                                                width = sc.nextDouble();}
                                        convertArea(rectangleCalc(length,width));
                                        System.out.println("The area of rectangle is :" + msq + " msq, " + cmsq  + " cmsq, " + Math.floor(mmsq*100)/100 + " mmsq.");
                                        break;
                                case 3:
                                        System.out.println("Enter the base (in mm) of the triangle as real.");
                                        base = sc.nextDouble();


                                        while (base<=0){
                                                System.out.println("Error. Input again");
                                                base = sc.nextDouble();}
                                        System.out.println("Enter the height (in mm) of the triangle as real.");
                                        height = sc.nextDouble();


                                        while (height<=0){
                                                System.out.println("Error. Input again");
                                                height = sc.nextDouble();}


                                        convertArea(triangleCalc(base, height));
                                        System.out.println("The area of triangle is: " + msq + " msq, " + cmsq + " cmsq, " + Math.floor(mmsq*100)/100 + " mmsq.");
                                        break;
                                case 4:
                                       //the 3 arrays have been declared as global
                                        readFile(circle, rectangle, triangle);
										output(circle,rectangle,triangle);

                                        break;
                                case 5:

                                        System.out.println("Program has ended.");
                                        System.exit(0);     
                        }
                }     
                while (choice !=5);
        } 
        
        public static double circleCalc(int diameter){
                double areacirc = PI * (diameter/2) * (diameter/2);
                return areacirc;
        }


        public static double rectangleCalc(double length, double width){
                double arearect = length * width;
                return arearect;
        }


        public static double triangleCalc(double base, double height){
                double areatri = (base*height)/200;
                return areatri;
        }


        public static void convertArea(double area){
                msq = (int) area/10000;
                cmsq = (int) area % 10000;
                mmsq = ((double) (area-(int)area)*100);
        }
        public static void readFile(double[] circle, double[] rectangle, double[] triangle){
                Scanner sc = new Scanner(System.in);

                System.out.println("Input file name");
                String fileName = sc.nextLine();
                int circleCount =0, rectangleCount = 0,triangleCount = 0;

                FileInputStream fileStrm = null;
                InputStreamReader rdr;
                BufferedReader bufrdr;

                try{
                        fileStrm = new FileInputStream(fileName);
                        rdr = new InputStreamReader(fileStrm);
                        bufrdr = new BufferedReader(rdr);
                        String line;
                        
                        validatingFile(fileName);

                        line = bufrdr.readLine();
                        
                        while (line != null){
                                switch(line){
                                        case "C":
                                                line = bufrdr.readLine();
                                                int diam = Integer.parseInt(line);
                                                if (diam <=0){
                                                        System.out.println("Diameter is negative");
                                                        System.exit(0);
                                                }
                                                else

                                                        if (circleCount < 20){
                                                                double area = circleCalc(diam);
                                                                circle[circleCount] = area;
                                                                circleCount++; 
                                                        }
                                                break;
                                        case "T":
                                                line = bufrdr.readLine();
                                                double base = Double.parseDouble(line);
                                                line = bufrdr.readLine();
                                                double height = Double.parseDouble(line);
                                                if (base <= 0 || height <=0){
                                                        System.out.println("Error. Value is negative");
                                                        System.exit(0);

                                                }
                                                else
                                                        if (triangleCount <20){
                                                                double area = triangleCalc(base,height);
                                                                triangle[triangleCount] =area;
                                                                triangleCount++;
                                                        }	

                                                break;
                                        case "R":
                                                line = bufrdr.readLine();
                                                double length = Double.parseDouble(line);
                                                line = bufrdr.readLine();
                                                double width = Double.parseDouble(line);
                                                if (length <= 0 || width <=0){
                                                        System.out.println("Error. Value is negative");
                                                        System.exit(0);

                                                }
                                                else
                                                        if (rectangleCount <20){
                                                                double area = rectangleCalc(length,width);
                                                                rectangle[rectangleCount] = area;
                                                                rectangleCount++;
                                                        }	
                                                break;
                                }
                                line = bufrdr.readLine();
                        }	
                        fileStrm.close();
                }
                catch (FileNotFoundException e){
                        System.out.println("File not found " + e.getMessage());
                }
                catch (IOException ex2){
                        System.out.println("Error in file processing");
                }
                             	
        }
        public static void output(double[] circle, double[] rectangle, double[] triangle){
                FileOutputStream fileStrm = null;
                PrintWriter pw;
				int i =0, x =0, z =0;
                try{
                        fileStrm = new FileOutputStream("output.txt");
                        pw = new PrintWriter(fileStrm);
						
                       do{
                                pw.println("R, " + rectangle[i]);
                                i++;
                        }while (rectangle[i] != 0.0);
                        do{
                                pw.println("C, " + circle[x]);
                                x++;
                        }while (circle[x] != 0.0);
                        do{
                                pw.println("T, " + triangle[z]);
                                z++;
                        }while (triangle[z] != 0.0);
                        pw.close();
                }
                catch (IOException e){
                }
        }
        public static void validatingFile(String fileName){
        	FileInputStream fileStrm = null;
            InputStreamReader rdr;
            BufferedReader bufrdr;
			int emptyLines = 0;
              try{
                        fileStrm = new FileInputStream(fileName);
                        rdr = new InputStreamReader(fileStrm);
                        bufrdr = new BufferedReader(rdr);
                        String line;
        				
        				line = bufrdr.readLine();
        				while (line != null){
        						emptyLines++;
        						line = bufrdr.readLine();
        				}
        				if (emptyLines ==0){
        						System.out.println("File is empty");
        						System.exit(0);
        				}
        
        		}
        		catch (FileNotFoundException e){
                        System.out.println("File not found " + e.getMessage());
                }
                catch (IOException ex2){
                        System.out.println("Error in file processing");
                }
        
        
        }
        
}
