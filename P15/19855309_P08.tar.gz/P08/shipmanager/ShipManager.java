import java.util.*;
public class  ShipManager
{
	public static void main(String [] args)
	{
		UserInterface UI = new UserInterface();
		UI.mainMenu();
	}
}
